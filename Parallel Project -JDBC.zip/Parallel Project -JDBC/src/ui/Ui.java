package ui;
import bean.Account;
import service.ServiceClass;
import bean.Customer;

//import dao.DaoClass;
import exception.PaymentWalletException;

import java.util.Scanner;



//----------------------------------------------- UI ---------------------------------------------------------------------------------------------



public class Ui {
     static Scanner sc = new Scanner(System.in);
	 static ServiceClass ser = new ServiceClass();
	 static Customer c = new Customer();
	 
	 
//-----------------------------------------------------SHOW BALANCE-------------------------------------------------------------------------------
	public static void showBalance() 
	{
		Customer c = new Customer();
		System.out.println("Enter the Account number");
		int ac_no= sc.nextInt();
		try {
			c = ser.showBal(ac_no) ;
		} catch (PaymentWalletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		
		if(c.getcName() != null)
		{
		System.out.println("Name of Customer:"+c.getcName());
		System.out.println("Address:"+c.getAddrs());
		System.out.println("Contact No:"+c.getPhone());
		System.out.println("Account No:"+c.getAcc().getAc_no());
		System.out.println("Account Type:"+c.getAcc().getType());
		System.out.println("Account Balance:"+c.getAcc().getAc_balance());
		}
		else
		{
			System.out.println("Account Number  Entered not present ");
		}
		
	}
	
//===================================================SHOW BALANCE END===================================================================================
	
	
	
//-----------------------------------------------------CREATE ACCOUNT-----------------------------------------------------------------------------------
	
	public static void createAccount()
	{
		System.out.println("Enter Details");
	Scanner sc = new Scanner(System.in);
		System.out.println("Enter Name");
		String nm = sc.nextLine();
		System.out.println("Enter Address");
		String addr = sc.nextLine();
		System.out.println("Enter Phone no");
		String num = sc.next();
		if(validateNumber(num)!= true)
		{
			System.out.println("Invalid number. Try Again");
			System.exit(0);
		}
		System.out.println("Enter Account type - SAVINGS or CURRENT");
		String type = sc.next().toUpperCase();
		double bal=0;
		if(type.equals("SAVINGS"))
				{
			System.out.println("Enter amount greater than or equal to 1000");
			System.out.println("Enter the amount you want to Deposit ");
			bal = sc.nextDouble();
			if(validateBalance(bal))
			{
				
				Account a = new Account( type , bal);
				Customer c = new Customer (nm , addr, num ,a);
				ser.createAccount(c);
				System.out.println("Account Created");
				System.out.println("Name of Customer:"+c.getcName());
				System.out.println("Address:"+c.getAddrs());
				System.out.println("Contact No:"+c.getPhone());
				System.out.println("Account No:"+c.getAcc().getAc_no());
				System.out.println("Account Type:"+c.getAcc().getType());
				System.out.println("Account Balance:"+c.getAcc().getAc_balance());
				
			}
			else
			{
				System.out.println("Balance Entered is less than 1000");
			}
		}
		else if(type.equals("CURRENT"))
		{
			System.out.println("Enter the amount you want to deposit");
			bal = sc.nextDouble();
			Account a = new Account( type , bal);
			Customer c = new Customer (nm , addr, num ,a);
			ser.createAccount(c);
			System.out.println("Account Created");
			System.out.println("Name of Customer:"+c.getcName());
			System.out.println("Address:"+c.getAddrs());
			System.out.println("Contact No:"+c.getPhone());
			System.out.println("Account No:"+c.getAcc().getAc_no());
			System.out.println("Account Type:"+c.getAcc().getType());
			System.out.println("Account Balance:"+c.getAcc().getAc_balance());
			
		}
		else
		{
			try {
				throw new PaymentWalletException("Invalid Account Type");
			} catch (PaymentWalletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}			
	}
	

	
	private static boolean validateNumber(String num) {
		
		
		return ser.validateNumber(num);
	}

	private static boolean validateBalance(double bal) {


	return ser.validateBalance(bal);
}

//=============================================================CREATE ACCOUNT END=======================================================================
	
	
	
//--------------------------------------------------PRINT TRANSACTION------------------------------------------------------------------------------------	
		private static void printTransactions() throws PaymentWalletException {
			System.out.println("Enter account Number to see transactions");
	        int ac_no;
	        ac_no=sc.nextInt();
	       // Customer c=new Customer();
	        if(ser.getAccountDetails(ac_no)==null )
			{
				System.out.println("Incorrect Account Number");
			}
			else
			{
	        System.out.println(ser.printTransaction(ac_no));
			}
			
		}

//==============================================PRINT TRANSACTION END==================================================================================
		
		
		
		
//------------------------------------------------- FUND TRANSFER------------------------------------------------------------------------------------	
			private static void fundTransfer() throws PaymentWalletException {
				Customer c = new Customer();
				Customer c1 = new Customer();
				System.out.println("Enter the Account number from which you want to transfer amount");
				int ac1 = sc.nextInt();
				System.out.println("Enter the Account number to which you want to transfer amount");
				int ac2 = sc.nextInt();
				System.out.println("Enter the Amount");
				double amt = sc.nextDouble();
				try {
					ser.fundTransfer(ac1, ac2, amt);
				} catch (  PaymentWalletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				try
				{
					c= ser.showBal(ac1);
					c1 = ser.showBal(ac2);
				}
				catch (PaymentWalletException e)
				{
					e.printStackTrace();
				}
				if(c.getAcc().getAc_balance()>0 && c1.getAcc().getAc_balance()>0 )
				{
					System.out.println("Fund Transfered from "+ac1+" to "+ac2);
					System.out.println("/nTotal amount transfered is "+amt);
					System.out.println("Updated Balance is as follows");
					
					System.out.println("Name of Customer:"+c.getcName());
					System.out.println("Address:"+c.getAddrs());
					System.out.println("Contact No:"+c.getPhone());
					System.out.println("Account No:"+c.getAcc().getAc_no());
					System.out.println("Account Type:"+c.getAcc().getType());
					System.out.println("Account Balance:"+c.getAcc().getAc_balance());
					System.out.println(" ");
					c = ser.showBal(ac2);
					System.out.println("Name of Customer:"+c.getcName());
					System.out.println("Address:"+c.getAddrs());
					System.out.println("Contact No:"+c.getPhone());
					System.out.println("Account No:"+c.getAcc().getAc_no());
					System.out.println("Account Type:"+c.getAcc().getType());
					System.out.println("Account Balance:"+c.getAcc().getAc_balance());
				}
				else
				{
					System.out.println("Account Number Not Found");
				}
			}
			
//====================================================FUND TRANSFER END==================================================================================
		
			
			
			
			
//------------------------------------------------------ WITHDRAW-------------------------------------------------------------------------------------
				private static void withdraw() throws PaymentWalletException {
					Customer c = new Customer();
					System.out.println("ENter the Account number");
					int ac_no = sc.nextInt();
					System.out.println("Enter the amount");
					double amt = sc.nextDouble();
					try
					{
					c = ser.withdraw(ac_no, amt);
					}
					catch (PaymentWalletException e)
					{
						e.printStackTrace();
					}
					if(c.getcName() !=null)
					{
						System.out.println("Name of Customer:"+c.getcName());
						System.out.println("Address:"+c.getAddrs());
						System.out.println("Contact No:"+c.getPhone());
						System.out.println("Account No:"+c.getAcc().getAc_no());
						System.out.println("Account Type:"+c.getAcc().getType());
						System.out.println("Account Balance:"+c.getAcc().getAc_balance());
						
					}
					else
					{
						System.out.println("Incorrect Account Number");
					}
				}

//======================================================WITHDRAW END==================================================================================
				
	
				
//------------------------------------------------------- DEPOSIT-------------------------------------------------------------------------------------

					private static void deposit() throws PaymentWalletException {
						Customer c = new Customer();
						System.out.println("Enter your Account number");
						int ac_no = sc.nextInt();
						System.out.println("Enter the Amount");
						double amt = sc.nextDouble();
						try
						{
							c = ser.deposit(ac_no, amt);		
						}
						catch(PaymentWalletException e)
						{
							e.printStackTrace();
						}
						if(c ==null)
						{
							System.out.println("Incorrect Account Number");
						}
						else
						{
							System.out.println("Name of Customer:"+c.getcName());
							System.out.println("Address:"+c.getAddrs());
							System.out.println("Contact No:"+c.getPhone());
							System.out.println("Account No:"+c.getAcc().getAc_no());
							System.out.println("Account Type:"+c.getAcc().getType());
							System.out.println("Account Balance:"+c.getAcc().getAc_balance());
//							ser.getDetails(ac_no).getAcc().setTransactionDetails("Deposit Amount : " +amt);
							 ser.getAccountDetails(ac_no).getAcc().setTransactionDetails("Deposited Amount "+amt);;
							
						}	
					}	
					
//=====================================================DEPOSIT END==================================================================================
					

//====================Empty Table=====					
					private static void emptyTable() {
					
						ser.emptyTable();
						
					}
					
//========Empty Table END				
					
					
					
//------------------------------------------------------------MAIN-------------------------------------------------------------------------------
	public static void main(String args[]) throws PaymentWalletException
	{
		String ch;
		int no_of_run =0;
		
		do{
			if(no_of_run==0)
				emptyTable();
		System.out.println("MENU");
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.Withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Transactions");
		System.out.println("7.Exit");
		
		int choice;
		 Scanner sc = new Scanner(System.in);
		choice = sc.nextInt();
		if(choice>0 && choice<7)
		{
			if(no_of_run==0 && choice!=1 ) {
			
			System.out.println("Currently no Accounts in Bank. First you need to Create Account!");
		}
		else
		{
			no_of_run++;
			switch(choice)
			{
			case 1 :
				createAccount();
					break;
			case 2 :
					showBalance();
					break;
			case 3:
					deposit();
					break;
			case 4:
					withdraw();
					break;
			case 5:
					fundTransfer();
					break;
			case 6:
				 printTransactions();
			    
					break;
			case 7:
				
				
				System.exit(0);
			default:
				System.out.println("Wrong choice");
				
				
				
			}
				}
		}
		else
		{
			System.out.println("Enter Correct Choice");
		}
		System.out.println("Do you want to continue ? Y or N");	
		ch= sc.next().toUpperCase();
			
	
	}while(!"N".equals(ch));
	}

	

	
//========================================================MAIN END==================================================================================
	


}

//========================================================== UI END =======================================================================================
