package service;
import bean.Customer;
import exception.PaymentWalletException;
public interface ServiceIntf {

	public void createAccount(Customer c) ;
	public Customer showBal(int ac_no)  throws PaymentWalletException ;
	Customer deposit(int ac_no ,double amt)  throws PaymentWalletException;
	Customer withdraw(int ac_no , double amt)  throws PaymentWalletException;
	void fundTransfer(int ac1 , int ac2 , double amt)  throws PaymentWalletException;
	public String printTransaction(int ac_no);
	public void emptyTable();
	Customer getAccountDetails(int num)  throws PaymentWalletException;
	public boolean validateBalance(double bal);
	public boolean validateNumber(String num);
}
