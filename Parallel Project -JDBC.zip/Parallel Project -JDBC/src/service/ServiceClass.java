package service;
import dao.DaoClass;
import exception.PaymentWalletException;
import bean.Customer;
import bean.Account;



public class ServiceClass implements ServiceIntf{

	DaoClass dao = new DaoClass();
	Customer c = new Customer();
	
	@Override
	public void createAccount(Customer c) {
		
		dao.storeDetails(c);
		
		
	}

	@Override
	public Customer showBal(int ac_no) throws PaymentWalletException {
		
		c =dao.showBalance(ac_no);
		
		return c;
	}

	@Override
	public Customer deposit(int ac_no, double amt) throws PaymentWalletException {
		c = dao.deposit(ac_no, amt);
		return c;
	}

	@Override
	public Customer withdraw(int ac_no, double amt) throws PaymentWalletException {
		c  = dao.withdraw(ac_no, amt);
		return c;
	}

	@Override
	public void fundTransfer(int ac1, int ac2, double amt)  throws PaymentWalletException {
		dao.fundTransfer(ac1, ac2, amt);
		
	}

	@Override
	public Customer getAccountDetails(int num) throws PaymentWalletException {
		c = dao.showBalance(num);
		return c;
		
	}

	@Override
	public String printTransaction(int ac_no) {
		String trnsc = dao.printTransaction(ac_no);
		// TODO Auto-generated method stub
		return trnsc;
	}

	public void emptyTable() {
		dao.emptyTable();
		
	}

	@Override
	public boolean validateBalance(double bal) {

		
		return dao.validateBalance(bal);
	}

	@Override
	public boolean validateNumber(String num) {
		
		
		return dao.validateNumber(num);
	}



}
