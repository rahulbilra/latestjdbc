package bean;



public class Account {
	
	  public enum acType{
			SAVINGS,CURRENT;
		}


	private static int ac_no=1000;
	private acType type;
	private double ac_balance;
	private String transactionDetails=" ";
	
	public Account()
	{
		super();
		ac_no++;
	}
	
	public Account(String type, double ac_balance) {
		super();
		ac_no++;
		
		this.ac_balance = ac_balance;
		this.type = acType.valueOf(type);
	}
	 public void setTransactionDetails(String transactionDetails) {
	        this.transactionDetails = this.transactionDetails+" "+transactionDetails+"\n";
	    }


	public int getAc_no() {
		return ac_no;
	}


	public acType getType() {
		return type;
	}


	public void setType(acType type) {
		this.type = type;
	}


	public double getAc_balance() {
		return ac_balance;
	}


	public String getTransactionDetails() {
        return transactionDetails;
    }
	public void setAc_balance(double ac_balance) {
		this.ac_balance = ac_balance;
	}
	
	public void setAccount_no(int num)

	{
		this.ac_no = num;
	}
	@Override
	public String toString() {
		return "Account [ac_no=" + ac_no + ", type=" + type + ", ac_balance=" + ac_balance + "]";
	}
	
	
}
