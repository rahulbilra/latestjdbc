package util;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class JdbcFactory {
	
	// Creating Properties reference
		private static Properties p;

		// Static initializer block
		static {
			try {
				p = new Properties();
				// Loading the file - "dbinfo.txt"
				p.load(new FileReader("src/dbinfo.txt"));
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		// private Constructor to avoid instantiation
		private JdbcFactory() {
		}

		/**
		 * Factory Method that returns Connection object
		 * 
		 * @return conn (Connection object)
		 * @throws SQLException
		 */
		public static Connection getConnection() throws SQLException {
			String url = p.getProperty("url");
			String username = p.getProperty("username");
			String password = p.getProperty("password");
			String driver = p.getProperty("driver");
			Connection conn = null;

			// Registering driver
			try {
				Class.forName(driver);
			} catch (ClassNotFoundException e) {
				throw new SQLException(e.getMessage());
			}

			// Get Connection
			conn = DriverManager.getConnection(url, username, password);

			return conn;

		}

}
