package dao;
import bean.Customer;

import exception.PaymentWalletException;
public interface DaoIntf {
	
	Customer showBalance(int num)  throws PaymentWalletException;
	void storeDetails(Customer c);
	Customer deposit(int ac_no , double amt)  throws PaymentWalletException;
	Customer withdraw(int ac_no , double amt)  throws PaymentWalletException;
	void fundTransfer(int ac1 , int ac2 , double amt) throws PaymentWalletException;

	public String printTransaction(int ac_no)  throws PaymentWalletException;
	public void emptyTable();
	public boolean validateBalance(double bal);
	public boolean validateNumber(String num);

}
