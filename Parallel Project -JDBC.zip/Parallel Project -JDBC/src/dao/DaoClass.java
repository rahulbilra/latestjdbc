package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import bean.Account;
import bean.Customer;

import exception.PaymentWalletException;
import util.JdbcFactory;

public class DaoClass implements DaoIntf {

	static Customer c = new Customer();
	Map<Integer, Customer> mp = new HashMap<Integer, Customer>();

	// =================================== GET ACCOUNT DETAILS=========
	@Override
	public Customer showBalance(int num) throws PaymentWalletException {
		String sql = "SELECT * FROM CUSTOMER_MASTER WHERE AC_NO=" + num;
		Customer c = new Customer();
		Connection conn = null;
		int ac_no;
		String ac_type, cName, Addrs, Phone;
		double ac_bal;

		try {
			conn = JdbcFactory.getConnection();
			Statement stmnt = conn.createStatement();
			ResultSet rset = stmnt.executeQuery(sql);
			while (rset.next()) {
				c.setcName(rset.getString(1));
				c.setAddrs(rset.getString(2));
				c.setPhone(rset.getString(3));
				ac_no = (rset.getInt(4));
				ac_type = rset.getString(5);
				ac_bal = rset.getDouble(6);
				Account a = new Account(ac_type, ac_bal);
				a.setAccount_no(ac_no);
				c.setAcc(a);
				
			}

			if(c==null)
			{
				throw new PaymentWalletException("Account Not Found");
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}


		
		return c;
		
	}
	// ------------------------- GET ACCOUNT DETAILS END-------

	// ============================== CREATE ACCOUNT==============
	@Override
	public void storeDetails(Customer c) {

	
		Connection conn = null;

		try {
			conn = JdbcFactory.getConnection();
			String sql = "INSERT INTO Customer_Master values (?,?,?,?,?,?,?) ";
			PreparedStatement pstmnt = conn.prepareStatement(sql);
			pstmnt.setString(1, c.getcName());
			pstmnt.setString(2, c.getAddrs());
			pstmnt.setString(3, c.getPhone());
			pstmnt.setInt(4, c.getAcc().getAc_no());
			pstmnt.setString(5, c.getAcc().getType().name());
			pstmnt.setDouble(6, c.getAcc().getAc_balance());
			pstmnt.setString(7," ");
			pstmnt.executeUpdate();
			

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}
	// ---------------------- CREATE ACCOUNTEND------------------------

	// ======================= DEPOSIT=============
	@Override
	public Customer deposit(int ac_no, double amt) throws PaymentWalletException {

		
		String sql = "SELECT AC_BAlANCE FROM CUSTOMER_MASTER WHERE AC_NO=" + ac_no;
		
		Connection conn = null;
		String old_trans="";
		double ac_bal = 0;
		if (c == null) {
				
			throw new  PaymentWalletException("Account Number Not present");
			
		} else {

			try {
				conn = JdbcFactory.getConnection();
				Statement stmnt = conn.createStatement();
				ResultSet rset = stmnt.executeQuery(sql);
				while (rset.next()) {
					ac_bal = rset.getDouble("AC_BALANCE");
					

				}
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		double temp = ac_bal + amt;
		String sql2="SELECT TRANSACTIONS FROM CUSTOMER_MASTER WHERE AC_NO="+ac_no;
		
		try {
			conn =  JdbcFactory.getConnection();
			Statement stmnt = conn.createStatement();
			ResultSet rset = stmnt.executeQuery(sql2);
			
			while(rset.next())
			{
				old_trans = rset.getString("TRANSACTIONS");
				
				
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String sql1 = "UPDATE CUSTOMER_MASTER SET AC_BALANCE=?,TRANSACTIONS=? WHERE AC_NO=" + ac_no;

		
		
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement pstmnt = conn.prepareStatement(sql1);
			pstmnt.setDouble(1,temp);
			
			old_trans = old_trans.concat("\nDeposited Amount "+amt);
			
			
			pstmnt.setString(2, old_trans);
//			pstmnt.setInt(3,ac_no);
			
			
			int i=pstmnt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		c = showBalance(ac_no);
		//c.getAcc().setTransactionDetails("Deposited Amount "+amt);
		
		return c;

	}
	// ------------- DEPOSIT END---------------------------

	// ================================================WITHDRAW=====
	@Override
	public Customer withdraw(int ac_no, double amt)  throws PaymentWalletException {
		Customer c = new Customer();

		String sql = "SELECT AC_BALANCE FROM CUSTOMER_MASTER WHERE AC_NO=" + ac_no;

		Connection conn = null;
		double ac_bal = 0;
		String ac_type = "";
		String old_trans="";

		if (c == null) {

			try {
				throw new PaymentWalletException("Enter valid Account number");

			} catch (PaymentWalletException e) {

				e.printStackTrace();

			}
		} else {

			try {
				conn = JdbcFactory.getConnection();
				Statement stmnt = conn.createStatement();
				ResultSet rset = stmnt.executeQuery(sql);
				while (rset.next()) {
					ac_bal = rset.getDouble("AC_BALANCE");
					}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		
		double temp = ac_bal - amt;
String sql2="SELECT TRANSACTIONS FROM CUSTOMER_MASTER WHERE AC_NO="+ac_no;
		
		try {
			conn =  JdbcFactory.getConnection();
			Statement stmnt = conn.createStatement();
			ResultSet rset = stmnt.executeQuery(sql2);
			
			while(rset.next())
			{
				old_trans = rset.getString("TRANSACTIONS");
				
				
			}
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		String sql1 = "UPDATE CUSTOMER_MASTER SET AC_BALANCE=?,TRANSACTIONS=? WHERE AC_NO=" + ac_no;

		
		
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement pstmnt = conn.prepareStatement(sql1);
			pstmnt.setDouble(1,temp);
			
			old_trans = old_trans.concat("\nWithdraw Amount "+amt);
			
			
			pstmnt.setString(2, old_trans);
//			pstmnt.setInt(3,ac_no);
			
			
			int i=pstmnt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		c = showBalance(ac_no);
		//c.getAcc().setTransactionDetails("Deposited Amount "+amt);
		
		return c;

	}
	// ----------------------WITHDRAW END------------

	// ==========================================FUND TRANSFER========
	public void fundTransfer(int ac1, int ac2, double amt)  throws PaymentWalletException {

		Customer c1 = new Customer();
		if (c == null) {

			try {
				throw new PaymentWalletException("Enter valid Account number");

			} catch (PaymentWalletException e) {

				e.printStackTrace();

			}
		} else {
			withdraw(ac1, amt);
			deposit(ac2, amt);
				}
	}

	// -----------------------------------------FUND TRANSFER END


	//------------------------------------------- Print Transaction--
	
	public String printTransaction(int ac_no)
	{
		
		String sql1="SELECT TRANSACTIONS FROM CUSTOMER_MASTER WHERE AC_NO="+ac_no;
		Connection conn=null;
		Statement stmnt;
		String trnsc=" ";
		try {
			conn = JdbcFactory.getConnection();
			stmnt = conn.createStatement();
			ResultSet rset = stmnt.executeQuery(sql1);
			while(rset.next())
			{
				 trnsc= rset.getString("TRANSACTIONS");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
		
		return trnsc;
		
	}

	@Override
	public void emptyTable() {
		String sql1="TRUNCATE TABLE CUSTOMER_MASTER";
		Connection conn = null;
		try {
			conn = JdbcFactory.getConnection();
			PreparedStatement pstmnt = conn.prepareStatement(sql1); 
			pstmnt.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
		
		
	}

	@Override
	public boolean validateBalance(double bal) {

		if(bal>999)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}

	@Override
	public boolean validateNumber(String num) {

		if(num.length()==10)
		{
			return true;
		}
		else
		{
			return false;
		}
		
	}
	
	
}
