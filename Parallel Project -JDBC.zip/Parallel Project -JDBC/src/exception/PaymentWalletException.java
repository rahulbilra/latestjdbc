package exception;

public class PaymentWalletException extends Exception {

	public PaymentWalletException (String ex)
	{
		super(ex);

	}

}
