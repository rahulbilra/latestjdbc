package jdbcCon;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	
	private static Connection connection;
	public static Connection getConnection() throws SQLException
	{
		 try {
			 
			 Class.forName("oracle.jdbc.driver.OracleDriver");
			connection=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","TRG533","training533");
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		 return connection;
	

}
}
