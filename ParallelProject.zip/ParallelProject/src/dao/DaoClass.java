package dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.Map;

import bean.Account;
import bean.Account.accountType;
import bean.Customer;
import jdbcCon.DbUtil;




public class DaoClass implements DaoIntf {

	static 	Customer  c = new Customer();
	static Account acc=new Account();
	static String query;
	 Connection connection=null;
	  PreparedStatement pst=null;
	
	Map<Integer ,Customer > mp = new HashMap<Integer ,Customer>();
	
	/*@Override
	public Customer getAccountDetails(int num) throws Exception {
		ResultSet rs=null;
		
		try {
			
			connection=DbUtil.getConnection();
			Statement s=connection.createStatement();
			rs=s.executeQuery("select * from custom where ac_no="+num);
			while(rs.next())
			{
		c.setcName(rs.getString(1));
		c.setAddrs(rs.getString(2));
		c.setPhone(rs.getString(3));
		c.getAcc().setAccount_no(rs.getInt(4));
		c.getAcc().setType(accountType.valueOf(rs.getString(5).toUpperCase()));
		
		c.getAcc().setAccount_balance(rs.getDouble(6));
		
		
		
			}
			System.out.println("check");
			connection.close();
			return c;
		}
		catch(Exception e)
		{
			throw e;
		}
		
		//return mp.get(num);
		
			
	}*/

	@Override
	public void storeDetails(Customer c) {
		try {
			
		
		connection=DbUtil.getConnection();
		query="INSERT INTO CUSTOM VALUES (?,?,?,?,?,?)";
		
		
			pst=connection.prepareStatement(query);
			pst.setString(1,c.getcName());
			pst.setString(2, c.getAddrs());
			pst.setString(3,c.getPhone());
			pst.setInt(4,c.getAcc().getAc_no());
			pst.setString(5,c.getAcc().getType().toString());
			pst.setDouble(6,c.getAcc().getAccount_balance());
			
			pst.executeUpdate();
			System.out.println("i dont care");
			connection.close();
			System.out.println("i dont care");
			
		}
		
			catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	//mp.put(c.getAcc().getAc_no(), c);	
	}

	@Override
	public Customer deposit(int ac_no , double amt) throws Exception {
		
		try {
			connection=DbUtil.getConnection();
			
			ResultSet rs=null;
			
		
				Statement s=connection.createStatement();
			rs=s.executeQuery("select * from custom where ac_no=" +ac_no); 
		
				while(rs.next())
				{
				double temp=rs.getDouble(6)+amt;	
				query= "update custom set account_balance="+temp+"where ac_no="+ac_no;
				pst=connection.prepareStatement(query);
				pst.executeUpdate();
				
				
				Account at=new Account(temp);
				c.setAcc(at);
				}
			
		connection.close();
		System.out.println("checking");
		return c;
		
		}
		catch (Exception  e) {
			// TODO Auto-generated catch block
			throw e;
		}
	
	
	

	}

	@Override
	public Customer withdraw(int account_no, double amount) throws Exception {

		try {
			connection=DbUtil.getConnection();
			
			ResultSet rs=null;
			
		
				Statement s=connection.createStatement();
			rs=s.executeQuery("select * from custom where ac_no=" +account_no); 
		
				while(rs.next())
				{
				double temp=rs.getDouble(6)-amount;	
				query= "update custom set account_balance="+temp+"where ac_no="+account_no;
				pst=connection.prepareStatement(query);
				pst.executeUpdate();
				
				
				Account at=new Account(temp);
				c.setAcc(at);
				}
			
		connection.close();
		
		return c;
		
		}
		catch (Exception  e) {
			// TODO Auto-generated catch block
			throw e;
		}
	
	}

	@Override
	public void fundTransfer(int ac1, int ac2, double amount) {

		/*
		 * c = mp.get(ac1); double temp = c.getAcc().getAccount_balance() - amount;
		 * c.getAcc().setAccount_balance(temp);
		 * 
		 * c = mp.get(ac2); temp = c.getAcc().getAccount_balance() + amount;
		 * c.getAcc().setAccount_balance(temp);
		 */
	
		
	}

	@Override
	public Customer getDetails(int ac_no) throws Exception {

ResultSet rs=null;
		
		try {
			
			connection=DbUtil.getConnection();
			Statement s=connection.createStatement();
			rs=s.executeQuery("select * from custom where ac_no=" +ac_no);
			while(rs.next())
			{
		c.setcName(rs.getString(1));
		c.setAddrs(rs.getString(2));
		c.setPhone(rs.getString(3));
		
		String type=rs.getString(5);
		double account_balance=rs.getDouble(6);
		Account at= new Account(type,account_balance);
		c.setAcc(at);
		
			}
		
			connection.close();
			return c;
			
		}
		catch(Exception e)
		{
			throw e;
		}
		
		
	}

	
	
	
}
