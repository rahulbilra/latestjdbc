package dao;


import bean.Customer;
public interface DaoIntf {
	
	
	void storeDetails(Customer c);
	Customer deposit(int ac_no , double amt) throws Exception;
	Customer withdraw(int ac_no , double amt) throws Exception;
	void fundTransfer(int ac1 , int ac2 , double amt);
	Customer getDetails(int num) throws Exception ;

}
